/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { Hero } from './components/Hero';
import { InputArea } from './components/InputArea';
import { LivePreview } from './components/LivePreview';
import { CreationHistory, Creation } from './components/CreationHistory';
import { bringToLife } from './services/gemini';
import { ArrowUpTrayIcon, KeyIcon, ExclamationTriangleIcon, DocumentTextIcon } from '@heroicons/react/24/solid';
import { ThreeEarth } from './components/ThreeEarth';

declare global {
  interface Window {
    pdfjsLib?: any;
  }
}

const App: React.FC = () => {
  const [activeCreation, setActiveCreation] = useState<Creation | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [history, setHistory] = useState<Creation[]>([]);
  const [prompt, setPrompt] = useState('');
  const [hasPersonalKey, setHasPersonalKey] = useState(false);
  const [isQuotaExhausted, setIsQuotaExhausted] = useState(false);
  const [isHeroEditing, setIsHeroEditing] = useState(false);
  const importInputRef = useRef<HTMLInputElement>(null);
  const keyFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const init = async () => {
      const saved = localStorage.getItem('gemini_app_history');
      let loadedHistory: Creation[] = [];

      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          loadedHistory = parsed.map((item: any) => ({
              ...item,
              timestamp: new Date(item.timestamp)
          }));
        } catch (e) {
          console.error("Failed to load history", e);
        }
      }

      if (loadedHistory.length > 0) {
        setHistory(loadedHistory);
      } else {
        try {
           const exampleUrls = [
               'https://storage.googleapis.com/sideprojects-asronline/bringanythingtolife/vibecode-blog.json',
               'https://storage.googleapis.com/sideprojects-asronline/bringanythingtolife/cassette.json',
               'https://storage.googleapis.com/sideprojects-asronline/bringanythingtolife/chess.json'
           ];

           const examples = await Promise.all(exampleUrls.map(async (url) => {
               const res = await fetch(url);
               if (!res.ok) return null;
               const data = await res.json();
               return {
                   ...data,
                   timestamp: new Date(data.timestamp || Date.now()),
                   id: data.id || crypto.randomUUID()
               };
           }));
           
           const validExamples = examples.filter((e): e is Creation => e !== null);
           setHistory(validExamples);
        } catch (e) {
            console.error("Failed to load examples", e);
        }
      }

      // Check for custom key in local storage
      const customKey = localStorage.getItem('custom_api_key');
      if (customKey) {
        setHasPersonalKey(true);
      } else {
          // @ts-ignore
          if (window.aistudio) {
            // @ts-ignore
            const hasKey = await window.aistudio.hasSelectedApiKey();
            setHasPersonalKey(hasKey);
          }
      }
    };

    init();
  }, []);

  useEffect(() => {
    if (history.length > 0) {
        localStorage.setItem('gemini_app_history', JSON.stringify(history));
    }
  }, [history]);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          const base64 = reader.result.split(',')[1];
          resolve(base64);
        } else {
          reject(new Error('Failed to convert file to base64'));
        }
      };
      reader.onerror = (error) => reject(error);
    });
  };

  const fileToText = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsText(file);
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          resolve(reader.result);
        } else {
          reject(new Error('Failed to read file as text'));
        }
      };
      reader.onerror = (error) => reject(error);
    });
  };

  const handleSelectPersonalKey = async () => {
    // @ts-ignore
    if (window.aistudio) {
      // @ts-ignore
      await window.aistudio.openSelectKey();
      setHasPersonalKey(true);
      setIsQuotaExhausted(false);
    }
  };

  const handleUploadKeyFile = () => {
    keyFileInputRef.current?.click();
  };

  const handleKeyFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        const text = event.target?.result as string;
        if (text) {
            const key = text.trim();
            // Basic validation: check if it looks roughly like a key (not empty)
            if (key.length > 10) {
                localStorage.setItem('custom_api_key', key);
                setHasPersonalKey(true);
                setIsQuotaExhausted(false);
                alert("Custom API Key loaded successfully.");
            } else {
                alert("Invalid API Key file.");
            }
        }
        if (keyFileInputRef.current) keyFileInputRef.current.value = '';
    };
    reader.readAsText(file);
  };

  // Enhanced generation handler to support extra data from Hero
  const handleGenerate = async (file?: File, customPrompt?: string, url?: string) => {
    if (!file && !prompt.trim() && !customPrompt?.trim() && !url?.trim()) {
      alert("Please enter a prompt, upload a file, or provide a URL to start.");
      return;
    }

    setIsGenerating(true);
    setIsQuotaExhausted(false);
    setActiveCreation(null);

    try {
      let imageBase64: string | undefined;
      let mimeType: string | undefined;
      let promptSuffix = '';

      if (file) {
        // If file is an image or PDF, treat as visual attachment
        if (file.type.startsWith('image/') || file.type === 'application/pdf') {
             imageBase64 = await fileToBase64(file);
             mimeType = file.type.toLowerCase();
        } else {
            // If file is text/code/html, read as text and append to prompt
            try {
                const textContent = await fileToText(file);
                promptSuffix += `\n\nATTACHED FILE CONTENT (${file.name}):\n\`\`\`\n${textContent}\n\`\`\``;
            } catch (e) {
                console.error("Failed to read text file", e);
            }
        }
      }

      if (url) {
        promptSuffix += `\n\nREFERENCE URL: ${url}`;
      }

      const basePrompt = customPrompt || prompt;
      const finalPrompt = basePrompt + promptSuffix;

      const html = await bringToLife(finalPrompt, imageBase64, mimeType);
      
      if (html) {
        const newCreation: Creation = {
          id: crypto.randomUUID(),
          name: file ? file.name : (basePrompt.slice(0, 20) || 'Untitled App'),
          html: html,
          originalImage: imageBase64 && mimeType ? `data:${mimeType};base64,${imageBase64}` : undefined,
          timestamp: new Date(),
        };
        setActiveCreation(newCreation);
        setHistory(prev => [newCreation, ...prev]);
        setPrompt(''); 
      }

    } catch (error: any) {
      console.error("Failed to generate:", error);
      const errorMessage = typeof error === 'string' ? error : error?.message || '';
      if (errorMessage.includes('Requested entity was not found')) {
        setHasPersonalKey(false);
        // @ts-ignore
        if (window.aistudio) {
          // @ts-ignore
          await window.aistudio.openSelectKey();
          setHasPersonalKey(true);
        }
      } else if (errorMessage.includes('429') || errorMessage.includes('RESOURCE_EXHAUSTED')) {
        setIsQuotaExhausted(true);
      } else {
        alert("Something went wrong while bringing your idea to life. Please try again.");
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const handleUpdateCreation = (newHtml: string) => {
      if (!activeCreation) return;
      const updatedCreation = { ...activeCreation, html: newHtml };
      setActiveCreation(updatedCreation);
      setHistory(prev => prev.map(c => c.id === updatedCreation.id ? updatedCreation : c));
  };

  const handleUpdateTitle = (newTitle: string) => {
    if (!activeCreation) return;
    const updatedCreation = { ...activeCreation, name: newTitle };
    setActiveCreation(updatedCreation);
    setHistory(prev => prev.map(c => c.id === updatedCreation.id ? updatedCreation : c));
  };

  const handleDeleteCreation = (id: string) => {
      setHistory(prev => {
        const newHistory = prev.filter(c => c.id !== id);
        localStorage.setItem('gemini_app_history', JSON.stringify(newHistory));
        return newHistory;
      });
      if (activeCreation?.id === id) setActiveCreation(null);
  };

  const handleReset = () => {
    setActiveCreation(null);
    setIsGenerating(false);
  };

  const handleSelectCreation = (creation: Creation) => {
    setActiveCreation(creation);
  };

  const handleImportClick = () => {
    importInputRef.current?.click();
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const json = event.target?.result as string;
            const parsed = JSON.parse(json);
            if (parsed.html && parsed.name) {
                const importedCreation: Creation = {
                    ...parsed,
                    timestamp: new Date(parsed.timestamp || Date.now()),
                    id: parsed.id || crypto.randomUUID()
                };
                setHistory(prev => {
                    const exists = prev.some(c => c.id === importedCreation.id);
                    if (exists) return prev;
                    const next = [importedCreation, ...prev];
                    localStorage.setItem('gemini_app_history', JSON.stringify(next));
                    return next;
                });
                setActiveCreation(importedCreation);
            } else {
                alert("Invalid creation file format.");
            }
        } catch (err) {
            console.error("Import error", err);
            alert("Failed to import creation.");
        }
        if (importInputRef.current) importInputRef.current.value = '';
    };
    reader.readAsText(file);
  };

  const isFocused = !!activeCreation || isGenerating;

  return (
    <div className="h-[100dvh] bg-zinc-950 bg-dot-grid text-zinc-50 selection:bg-blue-500/30 overflow-y-auto overflow-x-hidden relative flex flex-col">
      <ThreeEarth isGenerating={isGenerating} />

      {isQuotaExhausted && !isFocused && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md animate-in fade-in duration-500">
           <div className="max-w-md w-full mx-4 bg-zinc-900 border border-zinc-800 rounded-2xl p-8 shadow-2xl text-center">
              <div className="w-16 h-16 bg-yellow-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <ExclamationTriangleIcon className="w-8 h-8 text-yellow-500" />
              </div>
              <h2 className="text-2xl font-bold mb-4">Quota Exhausted</h2>
              <p className="text-zinc-400 mb-8">
                The shared API key has reached its rate limit. To continue creating, please select a personal API key from a paid Google Cloud project or upload a key file.
              </p>
              <div className="flex flex-col gap-3">
                <button 
                  onClick={handleSelectPersonalKey}
                  className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold py-3 px-6 rounded-xl transition-all shadow-lg shadow-blue-500/20"
                >
                  <KeyIcon className="w-5 h-5" />
                  Select Personal API Key (Google)
                </button>
                <div className="flex items-center gap-2">
                    <div className="h-px bg-zinc-800 flex-1"></div>
                    <span className="text-xs text-zinc-500">OR</span>
                    <div className="h-px bg-zinc-800 flex-1"></div>
                </div>
                <button 
                  onClick={handleUploadKeyFile}
                  className="w-full flex items-center justify-center gap-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold py-3 px-6 rounded-xl transition-all border border-zinc-700 hover:border-zinc-600"
                >
                  <DocumentTextIcon className="w-5 h-5" />
                  Upload Key File
                </button>
                <button 
                  onClick={() => setIsQuotaExhausted(false)}
                  className="w-full text-zinc-500 hover:text-zinc-300 py-2 text-sm transition-colors mt-2"
                >
                  Dismiss
                </button>
              </div>
           </div>
        </div>
      )}

      <div 
        className={`
          min-h-full flex flex-col w-full max-w-7xl mx-auto px-4 sm:px-6 relative z-10 
          transition-all duration-700 cubic-bezier(0.4, 0, 0.2, 1)
          ${isFocused 
            ? 'opacity-0 scale-95 blur-sm pointer-events-none h-[100dvh] overflow-hidden' 
            : 'opacity-100 scale-100 blur-0'
          }
        `}
      >
        <div className="flex-1 flex flex-col justify-center items-center w-full py-12 md:py-20">
          <div className="w-full mb-8 md:mb-16">
              <Hero 
                prompt={prompt} 
                setPrompt={setPrompt} 
                onGenerate={(data) => handleGenerate(data?.file, undefined, data?.url)} 
                disabled={isFocused}
                isEditingExternal={isHeroEditing}
                onEditChange={setIsHeroEditing}
              />
          </div>

          <div className="w-full flex justify-center mb-8">
              <InputArea 
                onGenerate={(file, custom) => handleGenerate(file, custom)} 
                isGenerating={isGenerating} 
                disabled={isFocused}
                forceEdit={isHeroEditing}
              />
          </div>
        </div>
        
        <div className="flex-shrink-0 pb-6 w-full mt-auto flex flex-col items-center gap-6">
            <div className="w-full px-2 md:px-0">
                <CreationHistory history={history} onSelect={handleSelectCreation} onDelete={handleDeleteCreation} />
            </div>
            
            <div className="flex flex-col items-center gap-2">
              {hasPersonalKey && (
                <div className="flex items-center gap-1.5 text-[10px] text-green-500/70 font-mono uppercase tracking-widest">
                  <div className="w-1 h-1 bg-green-500 rounded-full animate-pulse"></div>
                  Using Personal Key
                </div>
              )}
            </div>
        </div>
      </div>

      <LivePreview
        creation={activeCreation}
        isLoading={isGenerating}
        isFocused={isFocused}
        onReset={handleReset}
        onUpdateCreation={handleUpdateCreation}
        onUpdateTitle={handleUpdateTitle}
        onImportArtifact={handleImportClick}
      />

      <div className={`fixed bottom-4 right-4 z-[60] flex items-center gap-4 transition-opacity duration-300 ${isFocused ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
        {!hasPersonalKey && !isFocused && (
            <div className="flex items-center gap-2">
               <button 
                  onClick={handleUploadKeyFile}
                  className="flex items-center space-x-2 px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-500 hover:text-white hover:border-zinc-700 transition-all shadow-xl group"
                  title="Upload Key File"
               >
                  <DocumentTextIcon className="w-4 h-4" />
               </button>
               <button 
                  onClick={handleSelectPersonalKey}
                  className="flex items-center space-x-2 px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-400 hover:text-white hover:border-zinc-700 transition-all shadow-xl group"
                  title="Set Custom Key"
               >
                  <KeyIcon className="w-4 h-4 group-hover:text-blue-400 transition-colors" />
                  <span className="text-[10px] font-bold uppercase tracking-wider hidden sm:inline">Set Custom Key</span>
               </button>
           </div>
        )}
        <button 
            onClick={handleImportClick}
            className="flex items-center space-x-2 p-2 text-zinc-500 hover:text-zinc-300 transition-colors opacity-60 hover:opacity-100"
            title="Import Artifact"
        >
            <span className="text-xs font-medium uppercase tracking-wider hidden sm:inline">Upload previous artifact</span>
            <ArrowUpTrayIcon className="w-5 h-5" />
        </button>
      </div>

      <input 
        type="file" 
        ref={importInputRef} 
        onChange={handleImportFile} 
        accept=".json" 
        className="hidden" 
      />
      <input 
        type="file" 
        ref={keyFileInputRef} 
        onChange={handleKeyFileChange} 
        accept=".txt,.json" 
        className="hidden" 
      />
    </div>
  );
};

export default App;
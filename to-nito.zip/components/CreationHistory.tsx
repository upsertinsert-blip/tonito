/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { ClockIcon, ArrowRightIcon, DocumentIcon, PhotoIcon, TrashIcon } from '@heroicons/react/24/outline';

export interface Creation {
  id: string;
  name: string;
  html: string;
  originalImage?: string; // Base64 data URL
  timestamp: Date;
}

interface CreationHistoryProps {
  history: Creation[];
  onSelect: (creation: Creation) => void;
  onDelete: (id: string) => void;
}

export const CreationHistory: React.FC<CreationHistoryProps> = ({ history, onSelect, onDelete }) => {
  if (history.length === 0) return null;

  return (
    <div className="w-full animate-in fade-in slide-in-from-bottom-8 duration-700">
      <div className="flex items-center space-x-3 mb-3 px-2">
        <ClockIcon className="w-4 h-4 text-zinc-500" />
        <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-500">Archive</h2>
        <div className="h-px flex-1 bg-zinc-800"></div>
      </div>
      
      {/* Horizontal Scroll Container */}
      <div className="flex overflow-x-auto space-x-4 pb-4 px-2 scrollbar-hide">
        {history.map((item) => {
          const isPdf = item.originalImage?.startsWith('data:application/pdf');
          return (
            <div key={item.id} className="group flex-shrink-0 relative w-48 h-32">
                <button
                onClick={() => onSelect(item)}
                className="flex flex-col text-left w-full h-full bg-zinc-900/50 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-600 rounded-xl transition-all duration-200 overflow-hidden shadow-lg"
                >
                {/* Preview Image / Placeholder */}
                <div className="h-16 w-full bg-zinc-950 relative overflow-hidden flex items-center justify-center">
                    {item.originalImage && !isPdf ? (
                        <img src={item.originalImage} alt="" className="w-full h-full object-cover opacity-40 group-hover:opacity-60 transition-opacity" />
                    ) : (
                        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10" />
                    )}
                    <div className="absolute inset-0 flex items-center justify-center">
                        {isPdf ? (
                            <DocumentIcon className="w-6 h-6 text-zinc-600" />
                        ) : !item.originalImage ? (
                            <DocumentIcon className="w-6 h-6 text-zinc-600" />
                        ) : null}
                    </div>
                </div>

                <div className="p-3 flex flex-col justify-between flex-1">
                    <h3 className="text-xs font-medium text-zinc-300 group-hover:text-white truncate pr-4">
                        {item.name}
                    </h3>
                    <div className="flex items-center justify-between">
                        <span className="text-[9px] font-mono text-zinc-600 group-hover:text-zinc-500">
                            {item.timestamp.toLocaleDateString([], { month: 'short', day: 'numeric' })}
                        </span>
                        <ArrowRightIcon className="w-3 h-3 text-blue-500/50 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                </div>
                </button>
                
                {/* Delete Button */}
                <button 
                    onClick={(e) => {
                        e.stopPropagation();
                        if (confirm('Delete this creation?')) onDelete(item.id);
                    }}
                    className="absolute top-1.5 right-1.5 p-1.5 bg-zinc-900/80 backdrop-blur-sm rounded-lg text-zinc-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all border border-zinc-700/50 hover:border-red-500/50"
                    title="Delete"
                >
                    <TrashIcon className="w-3.5 h-3.5" />
                </button>
            </div>
          );
        })}
      </div>
      <style>{`
        .scrollbar-hide::-webkit-scrollbar {
            display: none;
        }
        .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
      `}</style>
    </div>
  );
};

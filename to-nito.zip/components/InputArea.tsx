/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useCallback, useState, useRef, useEffect } from 'react';
import { ArrowUpTrayIcon, CpuChipIcon, SparklesIcon, CheckIcon } from '@heroicons/react/24/outline';

interface InputAreaProps {
  onGenerate: (file: File, customPrompt?: string) => void;
  isGenerating: boolean;
  disabled?: boolean;
  forceEdit?: boolean;
}

const PRESETS = [
  'a chaotic whiteboard',
  'a messy napkin sketch',
  'a rough wireframe',
  'a hand-drawn layout',
  'a design mockup',
  'a creative doodle',
  'a technical diagram',
  'a complex flow-chart'
];

export const InputArea: React.FC<InputAreaProps> = ({ onGenerate, isGenerating, disabled = false, forceEdit = false }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [customText, setCustomText] = useState('a chaotic whiteboard');
  const [isEditingText, setIsEditingText] = useState(false);
  const [presetIndex, setPresetIndex] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (forceEdit) {
      setIsEditingText(true);
    }
  }, [forceEdit]);

  const handleFile = (file: File) => {
    if (file.type.startsWith('image/') || file.type === 'application/pdf') {
      onGenerate(file, customText);
    } else {
      alert("Please upload an image or PDF.");
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
        handleFile(e.target.files[0]);
    }
  };

  const handleShuffle = (e: React.MouseEvent) => {
    e.stopPropagation();
    const nextIndex = (presetIndex + 1) % PRESETS.length;
    setPresetIndex(nextIndex);
    setCustomText(PRESETS[nextIndex]);
    setIsEditingText(false);
  };

  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      if (disabled || isGenerating) return;
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;

      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf("image") !== -1) {
          e.preventDefault();
          const blob = items[i].getAsFile();
          if (blob) {
            handleFile(blob);
          }
          break;
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [disabled, isGenerating, customText]);

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (disabled || isGenerating) return;
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  }, [disabled, isGenerating, customText]);

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (!disabled && !isGenerating) {
        setIsDragging(true);
    }
  }, [disabled, isGenerating]);

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleContainerClick = (e: React.MouseEvent) => {
    if (isEditingText) return;
    if (!disabled && !isGenerating) {
        fileInputRef.current?.click();
    }
  };

  useEffect(() => {
    if (isEditingText && textInputRef.current) {
        textInputRef.current.focus();
    }
  }, [isEditingText]);

  return (
    <div className="w-full max-w-4xl mx-auto perspective-1000 px-4 md:px-0">
      <div 
        className={`relative group transition-all duration-300 ${isDragging ? 'scale-[1.01]' : ''}`}
      >
        <div
          className={`
            relative flex flex-col items-center justify-center
            h-64 sm:h-72 md:h-80
            bg-zinc-900/30 
            backdrop-blur-sm
            rounded-2xl border border-dashed
            cursor-pointer overflow-hidden
            transition-all duration-300
            ${isDragging 
              ? 'border-blue-500 bg-zinc-900/50 shadow-[inset_0_0_20px_rgba(59,130,246,0.1)]' 
              : 'border-zinc-700 hover:border-zinc-500 hover:bg-zinc-900/40'
            }
            ${isGenerating ? 'pointer-events-none' : ''}
          `}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onClick={handleContainerClick}
          role="button"
          tabIndex={0}
        >
            <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
                 style={{backgroundImage: 'linear-gradient(#ffffff 1px, transparent 1px), linear-gradient(90deg, #ffffff 1px, transparent 1px)', backgroundSize: '32px 32px'}}>
            </div>
            
            <div className={`absolute top-4 left-4 w-4 h-4 border-l-2 border-t-2 transition-colors duration-300 ${isDragging ? 'border-blue-500' : 'border-zinc-600'}`}></div>
            <div className={`absolute top-4 right-4 w-4 h-4 border-r-2 border-t-2 transition-colors duration-300 ${isDragging ? 'border-blue-500' : 'border-zinc-600'}`}></div>
            <div className={`absolute bottom-4 left-4 w-4 h-4 border-l-2 border-b-2 transition-colors duration-300 ${isDragging ? 'border-blue-500' : 'border-zinc-600'}`}></div>
            <div className={`absolute bottom-4 right-4 w-4 h-4 border-r-2 border-b-2 transition-colors duration-300 ${isDragging ? 'border-blue-500' : 'border-zinc-600'}`}></div>

            <div className="relative z-10 flex flex-col items-center text-center space-y-6 w-full px-6 md:px-12 pt-4">
                <div className={`relative w-16 h-16 rounded-2xl flex items-center justify-center transition-transform duration-500 ${isDragging ? 'scale-110' : 'group-hover:-translate-y-1'}`}>
                    <div className={`absolute inset-0 rounded-2xl bg-zinc-800 border border-zinc-700 shadow-xl flex items-center justify-center ${isGenerating ? 'animate-pulse' : ''}`}>
                        {isGenerating ? (
                            <CpuChipIcon className="w-8 h-8 text-blue-400 animate-spin-slow" />
                        ) : (
                            <ArrowUpTrayIcon className={`w-8 h-8 text-zinc-300 transition-all duration-300 ${isDragging ? '-translate-y-1 text-blue-400' : ''}`} />
                        )}
                    </div>
                </div>

                <div className="flex flex-col items-center space-y-2 group/text">
                     <div className="text-xl md:text-2xl font-semibold text-white flex flex-col items-center relative">
                        <span>Bring</span>
                        <div className="flex items-center group/editor-row">
                          {isEditingText ? (
                              <div className="flex items-center gap-2">
                                <input 
                                    ref={textInputRef}
                                    type="text"
                                    value={customText}
                                    onChange={(e) => setCustomText(e.target.value)}
                                    onBlur={() => !forceEdit && setIsEditingText(false)}
                                    onKeyDown={(e) => e.key === 'Enter' && setIsEditingText(false)}
                                    className="bg-zinc-800 text-blue-400 border-none rounded px-2 py-1 text-center focus:ring-1 focus:ring-blue-500 mx-1 min-w-[240px]"
                                />
                                <button onClick={(e) => { e.stopPropagation(); setIsEditingText(false); }} className="p-1 hover:text-green-400 transition-colors">
                                  <CheckIcon className="w-5 h-5" />
                                </button>
                              </div>
                          ) : (
                              <span 
                                  onClick={(e) => { e.stopPropagation(); setIsEditingText(true); }}
                                  className="relative inline-block mx-1 text-blue-400 hover:text-blue-300 transition-colors group/edit"
                              >
                                  {customText}
                                  <span className="absolute bottom-1 left-0 w-full h-0.5 bg-blue-500/50 rounded-full"></span>
                              </span>
                          )}
                          {!isEditingText && (
                            <button 
                              onClick={handleShuffle}
                              title="Shuffle Prompt"
                              className="ml-2 p-1.5 rounded-full bg-zinc-800/50 border border-zinc-700 text-zinc-500 hover:text-blue-400 hover:border-blue-500/50 transition-all opacity-0 group-hover/text:opacity-100"
                            >
                                <SparklesIcon className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                        <span>to life</span>
                     </div>
                    <p className="text-zinc-500 text-sm md:text-base font-light tracking-wide pt-2">
                        Drag & Drop or Paste to upload
                    </p>
                </div>
            </div>

            <input
                ref={fileInputRef}
                type="file"
                accept="image/*,application/pdf"
                className="hidden"
                onChange={handleFileChange}
                disabled={isGenerating || disabled}
            />
        </div>
      </div>
    </div>
  );
};
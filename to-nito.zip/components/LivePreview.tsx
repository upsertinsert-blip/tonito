/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useEffect, useState, useRef } from 'react';
import { 
    ArrowDownTrayIcon, 
    PlusIcon, 
    ViewColumnsIcon, 
    CodeBracketIcon, 
    XMarkIcon,
    ArrowUturnLeftIcon,
    ArrowUturnRightIcon,
    PaperAirplaneIcon,
    PlayIcon,
    PhotoIcon,
    CubeTransparentIcon,
    ArrowUpTrayIcon,
    PencilIcon
} from '@heroicons/react/24/outline';
import { Creation } from './CreationHistory';
import { refineApp, generateCodePackage } from '../services/gemini';
// @ts-ignore
import JSZip from 'jszip';

interface LivePreviewProps {
  creation: Creation | null;
  isLoading: boolean;
  isFocused: boolean;
  onReset: () => void;
  onUpdateCreation: (newHtml: string) => void;
  onUpdateTitle: (newTitle: string) => void;
  onImportArtifact?: () => void;
}

// Add type definition for the global pdfjsLib
declare global {
  interface Window {
    pdfjsLib?: any;
  }
}

const LoadingStep = ({ text, active, completed }: { text: string, active: boolean, completed: boolean }) => (
    <div className={`flex items-center space-x-3 transition-all duration-500 ${active || completed ? 'opacity-100 translate-x-0' : 'opacity-30 translate-x-4'}`}>
        <div className={`w-4 h-4 flex items-center justify-center ${completed ? 'text-green-400' : active ? 'text-blue-400' : 'text-zinc-700'}`}>
            {completed ? (
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
            ) : active ? (
                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-pulse"></div>
            ) : (
                <div className="w-1.5 h-1.5 bg-zinc-700 rounded-full"></div>
            )}
        </div>
        <span className={`font-mono text-xs tracking-wide uppercase ${active ? 'text-zinc-200' : completed ? 'text-zinc-400 line-through' : 'text-zinc-600'}`}>{text}</span>
    </div>
);

const PdfRenderer = ({ dataUrl }: { dataUrl: string }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const renderPdf = async () => {
      if (!window.pdfjsLib) return;
      try {
        const loadingTask = window.pdfjsLib.getDocument(dataUrl);
        const pdf = await loadingTask.promise;
        const page = await pdf.getPage(1);
        const canvas = canvasRef.current;
        if (!canvas) return;
        const context = canvas.getContext('2d');
        const viewport = page.getViewport({ scale: 2.0 });
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        await page.render({ canvasContext: context, viewport: viewport }).promise;
      } catch (err) {
        console.error("Error rendering PDF:", err);
      }
    };
    renderPdf();
  }, [dataUrl]);
  return <canvas ref={canvasRef} className="max-w-full max-h-full object-contain shadow-xl border border-zinc-800/50 rounded" />;
};

export const LivePreview: React.FC<LivePreviewProps> = ({ creation, isLoading, isFocused, onReset, onUpdateCreation, onUpdateTitle, onImportArtifact }) => {
    const [loadingStep, setLoadingStep] = useState(0);
    const [activeSidePanel, setActiveSidePanel] = useState<'none' | 'code' | 'source'>('none');
    
    // Title Editing State
    const [isEditingTitle, setIsEditingTitle] = useState(false);
    const [editedTitle, setEditedTitle] = useState("");
    const titleInputRef = useRef<HTMLInputElement>(null);
    const refinementInputRef = useRef<HTMLInputElement>(null);

    // Refinement State
    const [refinePrompt, setRefinePrompt] = useState("");
    const [isRefining, setIsRefining] = useState(false);
    const [refineImage, setRefineImage] = useState<string | null>(null);
    const [refineImageMime, setRefineImageMime] = useState<string | null>(null);

    const [isExporting, setIsExporting] = useState(false);
    
    // Undo/Redo History
    const [history, setHistory] = useState<string[]>([]);
    const [historyIndex, setHistoryIndex] = useState(-1);
    
    // Code Editor State
    const [editableCode, setEditableCode] = useState("");
    
    // Update local state when creation changes
    useEffect(() => {
        if (creation?.html) {
            setEditableCode(creation.html);
            setEditedTitle(creation.name);
            if (history.length === 0 || history[historyIndex] !== creation.html) {
                 const newHistory = [creation.html];
                 setHistory(newHistory);
                 setHistoryIndex(0);
            }
        }
    }, [creation?.id]);

    useEffect(() => {
        if (creation?.html) {
            setEditableCode(creation.html);
        }
    }, [creation?.html]);

    useEffect(() => {
        if (isLoading) {
            setLoadingStep(0);
            const interval = setInterval(() => {
                setLoadingStep(prev => (prev < 3 ? prev + 1 : prev));
            }, 2000); 
            return () => clearInterval(interval);
        } else {
            setLoadingStep(0);
        }
    }, [isLoading]);

    useEffect(() => {
        const handleGlobalPaste = (e: ClipboardEvent) => {
            if (!creation || isLoading || isRefining) return;
            const target = e.target as HTMLElement;
            if (target.tagName === 'TEXTAREA' && !target.closest('.refinement-input')) return; 
            const items = e.clipboardData?.items;
            if (!items) return;
            for (let i = 0; i < items.length; i++) {
                if (items[i].type.indexOf("image") !== -1) {
                    e.preventDefault();
                    const blob = items[i].getAsFile();
                    if (blob) {
                         const reader = new FileReader();
                        reader.onload = (event) => {
                            const result = event.target?.result as string;
                            const [header, base64] = result.split(',');
                            const mime = header.match(/:(.*?);/)?.[1] || blob.type;
                            setRefineImage(base64);
                            setRefineImageMime(mime);
                        };
                        reader.readAsDataURL(blob);
                    }
                    break;
                }
            }
        };
        window.addEventListener('paste', handleGlobalPaste);
        return () => window.removeEventListener('paste', handleGlobalPaste);
    }, [creation, isLoading, isRefining]);

    useEffect(() => {
        if (isEditingTitle && titleInputRef.current) {
            titleInputRef.current.focus();
            titleInputRef.current.select();
            // User requested to activate refinement input when title is editing
            refinementInputRef.current?.focus();
        }
    }, [isEditingTitle]);

    const handleUndo = () => {
        if (historyIndex > 0) {
            const newIndex = historyIndex - 1;
            setHistoryIndex(newIndex);
            onUpdateCreation(history[newIndex]);
        }
    };

    const handleRedo = () => {
        if (historyIndex < history.length - 1) {
            const newIndex = historyIndex + 1;
            setHistoryIndex(newIndex);
            onUpdateCreation(history[newIndex]);
        }
    };

    const addToHistory = (html: string) => {
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(html);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
        onUpdateCreation(html);
    };

    const handleDownloadHtml = () => {
        if (!creation) return;
        const blob = new Blob([creation.html], { type: "text/html" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${creation.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.html`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const handleExportZip = async () => {
        if (!creation || isExporting) return;
        setIsExporting(true);
        try {
            const packageData = await generateCodePackage(creation.html);
            const zip = new JSZip();
            zip.file("index.html", packageData.html);
            zip.file("style.css", packageData.css);
            zip.file("script.js", packageData.js);
            zip.file("server.php", packageData.php);
            zip.file("database.sql", packageData.sql);
            zip.file("README.md", packageData.readme);
            if (creation.originalImage) {
                const mime = creation.originalImage.match(/data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+).*,.*/);
                let ext = "png";
                if (mime && mime[1]) {
                    if (mime[1] === 'application/pdf') ext = 'pdf';
                    else ext = mime[1].split('/')[1];
                }
                const base64Data = creation.originalImage.split(',')[1];
                zip.file(`reference_source.${ext}`, base64Data, {base64: true});
            }
            const content = await zip.generateAsync({type:"blob"});
            const url = URL.createObjectURL(content);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${creation.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_stack.zip`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        } catch (error: any) {
            console.error("Export failed", error);
            const errorMessage = typeof error === 'string' ? error : error?.message || '';
            if (errorMessage.includes('Requested entity was not found')) {
                // @ts-ignore
                if (window.aistudio) {
                    // @ts-ignore
                    await window.aistudio.openSelectKey();
                }
            } else {
                alert("Failed to create export package. Please try again.");
            }
        } finally {
            setIsExporting(false);
        }
    };

    const handleRefine = async (overridePrompt?: string) => {
        const promptToUse = overridePrompt || refinePrompt;
        if (!creation || (!promptToUse.trim() && !refineImage) || isRefining) return;
        setIsRefining(true);
        try {
            const newHtml = await refineApp(creation.html, promptToUse, refineImage || undefined, refineImageMime || undefined);
            addToHistory(newHtml);
            if (!overridePrompt) {
                setRefinePrompt("");
            }
            setRefineImage(null);
            setRefineImageMime(null);
        } catch (error: any) {
            const errorMessage = typeof error === 'string' ? error : error?.message || '';
            if (errorMessage.includes('Requested entity was not found')) {
                // @ts-ignore
                if (window.aistudio) {
                    // @ts-ignore
                    await window.aistudio.openSelectKey();
                }
            } else {
                alert("Failed to refine app.");
            }
        } finally {
            setIsRefining(false);
        }
    };

    const handleChaoticEdit = () => {
        handleRefine("Apply a 'chaotic whiteboard' sketch style to the entire application. Make it look hand-drawn, messy, and creative, but keep it functional.");
    };

    const handleCodeBlur = () => {
        if (editableCode !== creation?.html) {
            addToHistory(editableCode);
        }
    };

    const togglePanel = (panel: 'code' | 'source') => {
        setActiveSidePanel(prev => prev === panel ? 'none' : panel);
    };

    const handleSaveTitle = () => {
        if (editedTitle.trim() && editedTitle !== creation?.name) {
            onUpdateTitle(editedTitle);
        }
        setIsEditingTitle(false);
    };

  return (
    <div
      className={`
        fixed z-40 flex flex-col
        rounded-lg overflow-hidden border shadow-2xl
        transition-all duration-700 cubic-bezier(0.2, 0.8, 0.2, 1)
        ${isFocused
          ? 'inset-0 opacity-100 scale-100 rounded-none border-none'
          : 'top-1/2 left-1/2 w-[90%] h-[60%] -translate-x-1/2 -translate-y-1/2 opacity-0 scale-95 pointer-events-none'
        }
        ${isLoading ? 'bg-transparent' : 'bg-[#0E0E10] border-zinc-800'}
      `}
    >
      {/* Header */}
      <div className={`px-4 py-3 flex items-center justify-between border-b shrink-0 transition-colors duration-500 ${isLoading ? 'bg-transparent border-transparent' : 'bg-[#121214] border-zinc-800'}`}>
        <div className="flex items-center space-x-3 w-48">
           <div className="flex space-x-2 group/controls">
                <button 
                  onClick={onReset}
                  className="w-3 h-3 rounded-full bg-zinc-700 group-hover/controls:bg-red-500 hover:!bg-red-600 transition-colors flex items-center justify-center focus:outline-none"
                  title="Close"
                >
                  <XMarkIcon className="w-2 h-2 text-black opacity-0 group-hover/controls:opacity-100" />
                </button>
                <div className="w-3 h-3 rounded-full bg-zinc-700 group-hover/controls:bg-yellow-500 transition-colors"></div>
                <div className="w-3 h-3 rounded-full bg-zinc-700 group-hover/controls:bg-green-500 transition-colors"></div>
           </div>
           
           {!isLoading && creation && (
               <div className="flex items-center space-x-1 ml-4 border-l border-zinc-700 pl-4">
                   <button onClick={handleUndo} disabled={historyIndex <= 0} className="p-1 hover:bg-zinc-800 rounded text-zinc-400 disabled:opacity-30 transition-colors">
                       <ArrowUturnLeftIcon className="w-4 h-4" />
                   </button>
                   <button onClick={handleRedo} disabled={historyIndex >= history.length - 1} className="p-1 hover:bg-zinc-800 rounded text-zinc-400 disabled:opacity-30 transition-colors">
                       <ArrowUturnRightIcon className="w-4 h-4" />
                   </button>
               </div>
           )}
        </div>
        
        <div className="flex items-center space-x-2 text-zinc-400">
            {isLoading ? null : (
                isEditingTitle ? (
                    <input 
                        ref={titleInputRef}
                        type="text"
                        value={editedTitle}
                        onChange={(e) => setEditedTitle(e.target.value)}
                        onBlur={handleSaveTitle}
                        onKeyDown={(e) => e.key === 'Enter' && handleSaveTitle()}
                        className="bg-zinc-800 text-white border-none rounded-md px-2 py-0.5 text-xs font-mono w-48 focus:ring-1 focus:ring-blue-500 text-center"
                    />
                ) : (
                    <button 
                        onClick={() => creation && setIsEditingTitle(true)}
                        className="flex items-center space-x-2 hover:text-white transition-colors group/title"
                    >
                        <span className="text-[11px] font-mono uppercase tracking-widest truncate max-w-[200px]">
                            {creation ? creation.name : 'Preview'}
                        </span>
                    </button>
                )
            )}
        </div>

        <div className="flex items-center justify-end space-x-2 w-fit">
            {!isLoading && creation && (
                <>
                    <button 
                         onClick={() => togglePanel('source')}
                         className={`p-1.5 rounded-md transition-all flex items-center gap-2 text-xs font-mono ${activeSidePanel === 'source' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'text-zinc-500 hover:bg-zinc-800'}`}
                         disabled={!creation.originalImage}
                         title={!creation.originalImage ? "No source available" : "View Source"}
                    >
                         <PhotoIcon className="w-4 h-4" />
                         <span className="hidden sm:inline">Source</span>
                    </button>

                    <button 
                         onClick={() => togglePanel('code')}
                         className={`p-1.5 rounded-md transition-all flex items-center gap-2 text-xs font-mono ${activeSidePanel === 'code' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'text-zinc-500 hover:bg-zinc-800'}`}
                    >
                         <CodeBracketIcon className="w-4 h-4" />
                         <span className="hidden sm:inline">Code</span>
                    </button>

                    <div className="h-4 w-px bg-zinc-800 mx-1"></div>

                    <button 
                        onClick={handleExportZip}
                        disabled={isExporting}
                        className={`text-zinc-500 hover:text-blue-400 transition-colors p-1.5 rounded-md hover:bg-zinc-800 ${isExporting ? 'animate-pulse text-blue-500' : ''}`}
                    >
                         {isExporting ? <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"></div> : <CubeTransparentIcon className="w-4 h-4" />}
                    </button>

                    <button onClick={handleDownloadHtml} className="text-zinc-500 hover:text-zinc-300 transition-colors p-1.5 rounded-md hover:bg-zinc-800">
                        <ArrowDownTrayIcon className="w-4 h-4" />
                    </button>

                    <button onClick={onReset} className="flex items-center space-x-1 text-xs font-bold bg-white text-black hover:bg-zinc-200 px-3 py-1.5 rounded-md transition-colors ml-2">
                        <PlusIcon className="w-3 h-3" />
                        <span className="hidden sm:inline">New</span>
                    </button>
                </>
            )}
        </div>
      </div>

      <div className={`relative w-full flex-1 flex overflow-hidden transition-colors duration-500 ${isLoading ? 'bg-transparent' : 'bg-[#09090b]'}`}>
        {isLoading ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-8 w-full">
             <div className="w-full max-w-md space-y-8 drop-shadow-[0_0_15px_rgba(0,0,0,0.8)]">
                <div className="flex flex-col items-center">
                    <div className="w-12 h-12 mb-6 text-blue-400 animate-spin-slow">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                           <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </div>
                    <h3 className="text-zinc-100 font-mono text-lg tracking-tight">Constructing Environment</h3>
                </div>
                <div className="w-full h-1 bg-zinc-800/50 rounded-full overflow-hidden backdrop-blur-sm">
                    <div className="h-full bg-blue-500 shadow-[0_0_10px_#3b82f6] animate-[loading_3s_ease-in-out_infinite] w-1/3"></div>
                </div>
                 <div className="border border-zinc-700/50 bg-black/40 backdrop-blur-md rounded-lg p-4 space-y-3 font-mono text-sm shadow-2xl">
                     <LoadingStep text="Analyzing visual inputs" active={loadingStep === 0} completed={loadingStep > 0} />
                     <LoadingStep text="Identifying UI patterns" active={loadingStep === 1} completed={loadingStep > 1} />
                     <LoadingStep text="Generating functional logic" active={loadingStep === 2} completed={loadingStep > 2} />
                     <LoadingStep text="Compiling preview" active={loadingStep === 3} completed={loadingStep > 3} />
                 </div>
             </div>
          </div>
        ) : creation?.html ? (
          <div className="flex flex-col w-full h-full">
            <div className="flex-1 flex w-full overflow-hidden relative">
                {activeSidePanel === 'code' && (
                    <div className="w-full md:w-1/2 h-full border-r border-zinc-800 bg-[#121214] flex flex-col">
                        <div className="flex items-center justify-between px-4 py-2 bg-[#18181b] border-b border-zinc-800 shrink-0">
                             <span className="text-xs text-zinc-500 font-mono">index.html</span>
                             <span className="text-[10px] text-zinc-600 uppercase font-mono tracking-widest">Auto-save on blur</span>
                        </div>
                        <textarea 
                            value={editableCode}
                            onChange={(e) => setEditableCode(e.target.value)}
                            onBlur={handleCodeBlur}
                            className="flex-1 w-full h-full bg-[#09090b] text-zinc-400 font-mono text-sm p-4 focus:outline-none resize-none selection:bg-blue-500/20"
                            spellCheck={false}
                        />
                    </div>
                )}
                {activeSidePanel === 'source' && (
                    <div className="w-full md:w-1/2 h-full border-r border-zinc-800 bg-[#121214] flex flex-col">
                        <div className="flex-1 w-full h-full p-4 flex items-center justify-center overflow-auto bg-zinc-950/50 bg-dot-grid">
                            {creation.originalImage ? (
                                creation.originalImage.startsWith('data:application/pdf') ? (
                                    <PdfRenderer dataUrl={creation.originalImage} />
                                ) : (
                                    <img src={creation.originalImage} className="max-w-full max-h-full object-contain shadow-2xl rounded-lg border border-zinc-800" />
                                )
                            ) : null}
                        </div>
                    </div>
                )}
                <div className={`h-full bg-white transition-all duration-300 ${activeSidePanel !== 'none' ? 'hidden md:block md:w-1/2' : 'w-full'}`}>
                    <iframe srcDoc={creation.html} className="w-full h-full" sandbox="allow-scripts allow-forms allow-popups allow-modals allow-same-origin" />
                </div>
            </div>
            
            <div className="bg-[#121214] border-t border-zinc-800 flex items-center px-4 h-16 shrink-0 z-20 shadow-[0_-4px_10px_rgba(0,0,0,0.3)]">
                <div className="flex items-center gap-4 w-full max-w-7xl mx-auto">
                    <div className="relative group">
                        <div className="absolute -inset-1 bg-blue-500 rounded-full blur opacity-20 group-hover:opacity-40 transition duration-500"></div>
                        <div className="relative w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center shrink-0 shadow-lg">
                            {isRefining ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <SparklesIcon className="w-4 h-4 text-white" />}
                        </div>
                    </div>
                    
                    <div className="flex-1 flex flex-col relative group">
                        {refineImage && (
                            <div className="absolute bottom-full mb-4 left-0 group-hover:scale-110 transition-transform origin-bottom-left">
                                <div className="relative p-1 bg-zinc-800 rounded-lg border border-zinc-700 shadow-2xl">
                                    <img src={`data:${refineImageMime};base64,${refineImage}`} className="h-20 w-auto rounded object-cover" />
                                    <button onClick={() => { setRefineImage(null); setRefineImageMime(null); }} className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full p-1 shadow-lg hover:bg-red-500">
                                        <XMarkIcon className="w-3 h-3" />
                                    </button>
                                </div>
                            </div>
                        )}
                        <input 
                            ref={refinementInputRef}
                            type="text" 
                            value={refinePrompt}
                            onChange={(e) => setRefinePrompt(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleRefine()}
                            placeholder="Ask AI to make changes (or paste an image)..."
                            className="w-full bg-transparent border-none focus:ring-0 text-sm text-zinc-300 placeholder-zinc-600 h-10 refinement-input font-medium"
                            disabled={isRefining}
                        />
                    </div>

                    <div className="flex items-center gap-2 sm:gap-4">
                        <button
                           onClick={handleChaoticEdit}
                           disabled={isRefining}
                           className="flex items-center gap-1.5 px-2 py-1.5 text-xs font-mono text-zinc-400 hover:text-white hover:bg-zinc-800 rounded transition-colors"
                           title="Make Chaotic Whiteboard"
                        >
                            <PencilIcon className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">Chaotic</span>
                        </button>
                        
                        <button 
                            onClick={() => handleRefine()}
                            disabled={(!refinePrompt.trim() && !refineImage) || isRefining}
                            className="text-zinc-500 hover:text-blue-400 disabled:opacity-30 transition-all hover:scale-110"
                        >
                            <PaperAirplaneIcon className="w-5 h-5 -rotate-45" />
                        </button>
                        
                        <div className="h-8 w-px bg-zinc-800"></div>

                        <button 
                            onClick={onImportArtifact}
                            className="flex items-center gap-2 px-3 py-2 text-zinc-500 hover:text-zinc-200 transition-all group/upload"
                        >
                            <span className="text-[10px] font-bold uppercase tracking-[0.2em] opacity-60 group-hover/upload:opacity-100 hidden sm:inline">Upload Artifact</span>
                            <ArrowUpTrayIcon className="w-4 h-4 group-hover/upload:-translate-y-0.5 transition-transform" />
                        </button>
                    </div>
                </div>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
};

const SparklesIcon = ({ className }: { className?: string }) => (
    <svg className={className} fill="currentColor" viewBox="0 0 24 24"><path d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.455-2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.894 20.567L16.5 21.75l-.394-1.183a2.25 2.25 0 00-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 001.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 001.423 1.423l1.183.394-1.183.394a2.25 2.25 0 00-1.423 1.423z" /></svg>
);
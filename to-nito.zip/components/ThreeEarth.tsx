import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface ThreeEarthProps {
  isGenerating?: boolean;
}

export const ThreeEarth: React.FC<ThreeEarthProps> = ({ isGenerating = false }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const stateRef = useRef({
    isGenerating,
    zoom: 4,
    targetZoom: 4,
    rotationSpeed: 0.002,
    particleExpansion: 1.0,
  });

  // Update internal ref when prop changes to keep animation loop smooth
  useEffect(() => {
    stateRef.current.isGenerating = isGenerating;
    stateRef.current.targetZoom = isGenerating ? 2.2 : 4;
  }, [isGenerating]);

  useEffect(() => {
    if (!containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    containerRef.current.appendChild(renderer.domElement);

    // 1. Earth Setup
    const geometry = new THREE.SphereGeometry(1.5, 64, 64);
    const textureLoader = new THREE.TextureLoader();
    
    const earthTexture = textureLoader.load('https://raw.githubusercontent.com/mrdoob/three.js/master/examples/textures/planets/earth_atmos_2048.jpg');
    const earthMaterial = new THREE.MeshPhongMaterial({
      map: earthTexture,
      shininess: 8,
      emissive: new THREE.Color(0x112244),
      emissiveIntensity: 0.2,
    });

    const earth = new THREE.Mesh(geometry, earthMaterial);
    scene.add(earth);

    // 2. Dissemination Particles (The "Gemini Cloud")
    const particlesCount = 2500;
    const posArray = new Float32Array(particlesCount * 3);
    const particleSizes = new Float32Array(particlesCount);
    
    for (let i = 0; i < particlesCount; i++) {
      // Distribute particles in a shell around the earth
      const phi = Math.random() * Math.PI * 2;
      const theta = Math.acos((Math.random() * 2) - 1);
      const r = 1.6 + Math.random() * 0.4;
      
      posArray[i * 3] = r * Math.sin(theta) * Math.cos(phi);
      posArray[i * 3 + 1] = r * Math.sin(theta) * Math.sin(phi);
      posArray[i * 3 + 2] = r * Math.cos(theta);
      particleSizes[i] = Math.random() * 2;
    }

    const particlesGeometry = new THREE.BufferGeometry();
    particlesGeometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    
    const particlesMaterial = new THREE.PointsMaterial({
      size: 0.015,
      color: 0x4488ff,
      transparent: true,
      opacity: 0.6,
      blending: THREE.AdditiveBlending,
    });

    const particlesMesh = new THREE.Points(particlesGeometry, particlesMaterial);
    scene.add(particlesMesh);

    // 3. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xffffff, 1.5);
    sunLight.position.set(5, 3, 5);
    scene.add(sunLight);

    camera.position.z = 4;

    // Resize Handler
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // Animation variables
    let time = 0;

    const animate = () => {
      requestAnimationFrame(animate);
      time += 0.01;
      
      const { isGenerating, targetZoom } = stateRef.current;

      // Smooth Zoom Lerp
      camera.position.z += (targetZoom - camera.position.z) * 0.05;

      // Handle "Generating" Visual State
      if (isGenerating) {
        // Fast rotation
        earth.rotation.y += 0.008;
        particlesMesh.rotation.y += 0.012;
        
        // Pulse glow
        earthMaterial.emissiveIntensity = 0.5 + Math.sin(time * 4) * 0.3;
        particlesMaterial.opacity = 0.8 + Math.sin(time * 5) * 0.2;
        
        // Expand particles
        stateRef.current.particleExpansion += (1.4 - stateRef.current.particleExpansion) * 0.05;
      } else {
        // Standard slow rotation
        earth.rotation.y += 0.0015;
        particlesMesh.rotation.y += 0.002;
        
        // Calm glow
        earthMaterial.emissiveIntensity = 0.2;
        particlesMaterial.opacity = 0.4;
        
        // Reset particle shell
        stateRef.current.particleExpansion += (1.0 - stateRef.current.particleExpansion) * 0.05;
      }

      particlesMesh.scale.setScalar(stateRef.current.particleExpansion);

      renderer.render(scene, camera);
    };
    
    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      if (containerRef.current) containerRef.current.removeChild(renderer.domElement);
      geometry.dispose();
      earthMaterial.dispose();
      particlesGeometry.dispose();
      particlesMaterial.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div 
      ref={containerRef} 
      className={`fixed inset-0 pointer-events-none z-0 transition-all duration-1000 ${isGenerating ? 'opacity-100' : 'opacity-40'} mix-blend-screen`}
      style={{
        filter: isGenerating ? 'blur(1.5px)' : 'blur(0px)',
      }}
    />
  );
};
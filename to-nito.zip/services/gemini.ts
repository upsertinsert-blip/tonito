/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";

// Using gemini-3-pro-preview for complex coding tasks.
const GEMINI_MODEL = 'gemini-3-pro-preview';

const SYSTEM_INSTRUCTION = `You are an expert AI Engineer and Product Designer specializing in "bringing artifacts to life".
Your goal is to take a user prompt or uploaded file—which might be a polished UI design, a messy napkin sketch, a photo of a whiteboard, or a simple text description—and instantly generate a fully functional, interactive, single-page HTML/JS/CSS application.

CORE DIRECTIVES:
1. **Analyze & Abstract**: 
    - **If an image is provided**: Look at the layout, detect buttons, inputs, and patterns. Turn them into a modern, clean UI.
    - **If it's a real-world photo**: Gamify it or build a utility (e.g., a "Clean Up" game for a messy desk).
    - **If ONLY text is provided**: Interpret the user's intent creatively. Build a complete, aesthetically pleasing, and highly functional application that solves the user's request.

2. **NO EXTERNAL IMAGES**:
    - **CRITICAL**: Do NOT use <img src="..."> with external URLs.
    - **INSTEAD**: Use CSS shapes, inline SVGs, Emojis, or CSS gradients.

3. **Make it Interactive**: The output MUST NOT be static. Include buttons, state management, animations, or dynamic logic.
4. **Self-Contained**: Single HTML file with embedded CSS (<style>) and JS (<script>). Tailwind via CDN is allowed.
5. **Aesthetics**: Use modern UI principles—ample whitespace, nice typography (Inter), and smooth transitions.

RESPONSE FORMAT:
Return ONLY the raw HTML code. Do not wrap it in markdown code blocks. Start immediately with <!DOCTYPE html>.`;

const REFINE_SYSTEM_INSTRUCTION = `You are an expert Web Developer and UI/UX Designer.
Your task is to modify the provided HTML application based on the user's request and any provided reference images.

DIRECTIVES:
1. **Maintain Context**: Keep the existing functionality and style unless explicitly asked to change it.
2. **Single File**: Return the full, updated HTML file with CSS and JS embedded.
3. **No External Images**: Continue to avoid external image dependencies. Use CSS/SVG/Emoji.
4. **Targeted Changes**: Only modify the parts of the code relevant to the user's request. Do not rewrite unrelated sections.
5. **Visual References**: If an image is provided, use it as a reference for layout, style, colors, or content updates as requested.
6. **Robustness**: Ensure the code is valid and error-free.

RESPONSE FORMAT:
Return ONLY the raw HTML code. Do not wrap it in markdown code blocks. Start immediately with <!DOCTYPE html>.`;

const PACKAGE_SYSTEM_INSTRUCTION = `You are a Full Stack Web Developer.
Your task is to take a single-file HTML prototype (which contains embedded CSS and JS) and convert it into a modular, production-ready LAMP stack application.

DIRECTIVES:
1. **Separate Concerns**: Extract the CSS into a style.css file and the JavaScript into a script.js file. Update the HTML to link to these external files.
2. **Backend Logic (PHP)**: Create a \`server.php\` file that handles the data interactions implied by the prototype. 
3. **Database Schema (SQL)**: Create a \`database.sql\` file with the MySQL schema required to support the PHP backend.
4. **Readme**: Create a brief \`README.md\` explaining how to set up the stack.

RESPONSE FORMAT:
Return a JSON object containing the source code for each file.`;

/**
 * World-class retry logic with exponential backoff
 */
async function withRetry<T>(fn: () => Promise<T>, retries = 3, delay = 1000): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    const isQuotaError = error?.message?.includes('429') || error?.status === 'RESOURCE_EXHAUSTED';
    const isServerError = error?.message?.includes('500') || error?.message?.includes('503');
    
    if ((isQuotaError || isServerError) && retries > 0) {
      console.warn(`API error encountered. Retrying in ${delay}ms... (${retries} retries left)`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return withRetry(fn, retries - 1, delay * 2);
    }
    throw error;
  }
}

function getApiKey(): string | undefined {
    return localStorage.getItem('custom_api_key') || process.env.API_KEY;
}

export async function bringToLife(prompt: string, fileBase64?: string, mimeType?: string): Promise<string> {
  return withRetry(async () => {
    // Create new instance per call to ensure we use current API KEY
    const ai = new GoogleGenAI({ apiKey: getApiKey() });
    const parts: any[] = [];
    
    const baseInstruction = fileBase64 
      ? "Analyze this image/document and build a fully interactive web app based on it." 
      : "Build a fully interactive web app based on the following text description.";

    const finalPrompt = fileBase64 
      ? `${baseInstruction} ${prompt ? `\n\nUSER REQUEST: ${prompt}` : "Create a functional interpretation of this visual."}` 
      : prompt || "Create a high-quality interactive demo showcasing your creative UI/UX capabilities.";

    parts.push({ text: finalPrompt });

    if (fileBase64 && mimeType) {
      parts.push({
        inlineData: {
          data: fileBase64,
          mimeType: mimeType,
        },
      });
    }

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: { parts },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7, 
      },
    });

    let text = response.text || "<!-- Failed to generate content -->";
    text = text.replace(/^```html\s*/, '').replace(/^```\s*/, '').replace(/```$/, '');
    return text;
  });
}

export async function refineApp(currentHtml: string, prompt: string, imageBase64?: string, imageMimeType?: string): Promise<string> {
  return withRetry(async () => {
    const ai = new GoogleGenAI({ apiKey: getApiKey() });
    const parts: any[] = [
        { text: `CURRENT HTML CODE:\n${currentHtml}` },
        { text: `USER CHANGE REQUEST: ${prompt}` }
    ];

    if (imageBase64 && imageMimeType) {
        parts.push({
            inlineData: {
                data: imageBase64,
                mimeType: imageMimeType
            }
        });
        parts.push({ text: "REFERENCE IMAGE PROVIDED: Use this image to guide visual changes as requested." });
    }

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: GEMINI_MODEL,
        contents: { parts },
        config: {
            systemInstruction: REFINE_SYSTEM_INSTRUCTION,
            temperature: 0.5,
        }
    });

    let text = response.text || currentHtml;
    text = text.replace(/^```html\s*/, '').replace(/^```\s*/, '').replace(/```$/, '');
    return text;
  });
}

export async function generateCodePackage(currentHtml: string): Promise<{html: string, css: string, js: string, php: string, sql: string, readme: string}> {
  return withRetry(async () => {
    const ai = new GoogleGenAI({ apiKey: getApiKey() });
    const parts: any[] = [
        { text: `SOURCE HTML PROTOTYPE:\n${currentHtml}` }
    ];

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: GEMINI_MODEL,
        contents: { parts },
        config: {
            systemInstruction: PACKAGE_SYSTEM_INSTRUCTION,
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    html: { type: Type.STRING },
                    css: { type: Type.STRING },
                    js: { type: Type.STRING },
                    php: { type: Type.STRING },
                    sql: { type: Type.STRING },
                    readme: { type: Type.STRING }
                },
                required: ["html", "css", "js", "php", "sql", "readme"]
            }
        }
    });

    const json = JSON.parse(response.text || "{}");
    return json;
  });
}